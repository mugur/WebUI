using System;

namespace SandBox.WebUi.Account {
    public partial class RegisterSuccess : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {
            
        }
    }
}