using System;

namespace SandBox.WebUi.Account {
  public partial class ChangePasswordSuccess : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {

    }
  }
}