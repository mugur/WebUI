﻿using System;
using System.Collections.Generic;
using SandBox.Db;
using SandBox.Log;
using SandBox.WebUi.Base;

namespace SandBox.WebUi.Pages.Research
{
    public partial class NewResearch : BaseMainPage
    {
        protected new void Page_Load(object sender, EventArgs e)
        {
            base.Page_Load(sender, e);
            PageTitle = "Создание нового исследования";
            PageMenu = "~/App_Data/SideMenu/Research/ResearchMenu.xml";

            if (!IsPostBack)
            {
                List<string> vmList = IsUserInRole("Administrator") ? VmManager.GetVmReadyNameList() : VmManager.GetVmReadyNameList(UserId);
                List<string> mlwrList = MlwrManager.GetMlwrPathList();

                cbMachine.DataSource = vmList;
                cbMachine.DataBind();
                if (vmList.Count > 0) cbMachine.SelectedIndex = 0;

                cbMalware.DataSource = mlwrList;
                cbMalware.DataBind();
                if (vmList.Count > 0) cbMalware.SelectedIndex = 0;

                spinTime.AllowNull = false;
                spinTime.AllowUserInput = false;
                spinTime.Value = 1;
            }
        }

        protected void BtnCreateClick(object sender, EventArgs e)
        {
            Vm vm               = VmManager.GetVm(cbMachine.Value.ToString());
            Mlwr mlwr           = MlwrManager.GetMlwr(cbMalware.Value.ToString());
            Int32 timeLeft      = Convert.ToInt32(spinTime.Value);

            Int32 researchVmData = ResearchManager.AddResearchVmData(vm.Name, vm.Type, vm.System, vm.EnvType, vm.EnvMac, vm.EnvIp, vm.Description);
            Int32 researchId = ResearchManager.AddResearch(UserId, mlwr.Id, vm.Id, researchVmData, timeLeft, tbLir.Text);
            
            AddTasks(researchId);

            MLogger.LogTo(Level.TRACE, false, "Create research '" + tbLir.Text + "' by user '" + UserManager.GetUser(UserId).UserName + "'");
            Response.Redirect("~/Pages/Research/Current.aspx");
        }

        private void AddTasks(Int32 researchId)
        {
            String hideFilePar      = tbHideFile.Text;
            String lockFilePar      = tbLockDelete.Text;
            String hideRegistryPar  = tbHideRegistry.Text;
            String hideProcessPar   = tbHideProcess.Text;
            String setSignaturePar  = tbSetSignature.Text;
            String setExtensionPar  = tbSetExtension.Text;
            String setBandwidthPar  = tbSetBandwidth.Text;

            if (hideFilePar != String.Empty) TaskManager.AddTask(researchId, 1, hideFilePar);
            if (lockFilePar != String.Empty) TaskManager.AddTask(researchId, 2, lockFilePar);
            if (hideRegistryPar != String.Empty) TaskManager.AddTask(researchId, 3, hideRegistryPar);
            if (hideProcessPar != String.Empty) TaskManager.AddTask(researchId, 4, hideProcessPar);
            if (setSignaturePar != String.Empty) TaskManager.AddTask(researchId, 5, setSignaturePar);
            if (setExtensionPar != String.Empty) TaskManager.AddTask(researchId, 6, setExtensionPar);
            if (setBandwidthPar != String.Empty) TaskManager.AddTask(researchId, 7, setBandwidthPar);
        }
    }//end class
}//end namespace