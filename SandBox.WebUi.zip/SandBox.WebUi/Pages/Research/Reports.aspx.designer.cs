﻿//------------------------------------------------------------------------------
// <автоматически создаваемое>
//     Этот код создан программой.
//
//     Изменения в этом файле могут привести к неправильной работе и будут потеряны в случае
//     повторной генерации кода. 
// </автоматически создаваемое>
//------------------------------------------------------------------------------

namespace SandBox.WebUi.Pages.Research {
    
    
    public partial class Reports {
        
        /// <summary>
        /// cbResearch элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxComboBox cbResearch;
        
        /// <summary>
        /// btnCreate элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxButton btnCreate;
        
        /// <summary>
        /// labelNoItems элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxLabel labelNoItems;
        
        /// <summary>
        /// UpdatePanelReports элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::System.Web.UI.UpdatePanel UpdatePanelReports;
        
        /// <summary>
        /// linkGetTraffic элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxHyperLink linkGetTraffic;
        
        /// <summary>
        /// linkGetProcessList элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxHyperLink linkGetProcessList;
        
        /// <summary>
        /// linkGetRegistryList элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxHyperLink linkGetRegistryList;
        
        /// <summary>
        /// linkGetFileList элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxHyperLink linkGetFileList;
        
        /// <summary>
        /// gridViewReports элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxGridView.ASPxGridView gridViewReports;
        
        /// <summary>
        /// ReportLinqDataSource элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::System.Web.UI.WebControls.LinqDataSource ReportLinqDataSource;
    }
}
