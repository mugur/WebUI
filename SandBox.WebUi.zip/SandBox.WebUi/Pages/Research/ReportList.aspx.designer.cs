﻿//------------------------------------------------------------------------------
// <автоматически создаваемое>
//     Этот код создан программой.
//
//     Изменения в этом файле могут привести к неправильной работе и будут потеряны в случае
//     повторной генерации кода. 
// </автоматически создаваемое>
//------------------------------------------------------------------------------

namespace SandBox.WebUi.Pages.Research {
    
    
    public partial class ReportList {
        
        /// <summary>
        /// ASPxHyperLink1 элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxHyperLink ASPxHyperLink1;
        
        /// <summary>
        /// linkGetTraffic элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxHyperLink linkGetTraffic;
        
        /// <summary>
        /// linkGetProcessList элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxHyperLink linkGetProcessList;
        
        /// <summary>
        /// linkGetRegistryList элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxHyperLink linkGetRegistryList;
        
        /// <summary>
        /// linkGetFileList элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxEditors.ASPxHyperLink linkGetFileList;
        
        /// <summary>
        /// gridViewReports элемент управления.
        /// </summary>
        /// <remarks>
        /// Автоматически создаваемое поле.
        /// Для изменения переместите объявление поля из файла конструктора в файл кода программной части.
        /// </remarks>
        protected global::DevExpress.Web.ASPxGridView.ASPxGridView gridViewReports;
    }
}
